$('.carousel').carousel({
    interval: 6000
}); 

$(document).ready(function()
  {
      // MAKE SURE YOUR SELECTOR MATCHES SOMETHING IN YOUR HTML!!!
      $('.necklace').each(function() {
          $(this).qtip({
              content: {
                  text: $(this).next('.tooltiptext')
              },
              position: {
                  at: 'bottom center',
                  my: 'bottom center',
                target: $(window), // Track the mouse as the positioning target
                adjust: {
                    // Don't adjust continuously the mouse, just use initial position
                    mouse: false
                }},
            show: 'click',
            hide: 'click unfocus'
          });
      });
  });

  $(document).ready(function()
  {
      // MAKE SURE YOUR SELECTOR MATCHES SOMETHING IN YOUR HTML!!!
      $('.tshirt').each(function() {
          $(this).qtip({
              content: {
                  text: $(this).next('.tooltiptext2')
              },
              position: {
                at: 'bottom center',
                my: 'bottom center',
              target: $(window), // Track the mouse as the positioning target
              adjust: {
                  // Don't adjust continuously the mouse, just use initial position
                  mouse: false
                }
            },
            show: 'click',
            hide: 'click unfocus'
          });
      });
  });

  $(document).ready(function()
  {
      // MAKE SURE YOUR SELECTOR MATCHES SOMETHING IN YOUR HTML!!!
      $('.jeans').each(function() {
          $(this).qtip({
              content: {
                  text: $(this).next('.tooltiptext3')
              },
              position: {
                at: 'bottom center',
                my: 'bottom center',
              target: $(window), // Track the mouse as the positioning target
              adjust: {
                  // Don't adjust continuously the mouse, just use initial position
                  mouse: false
                }
            },
            show: 'click',
            hide: 'click unfocus'
          });
      });
  });

  $(document).ready(function()
  {
      // MAKE SURE YOUR SELECTOR MATCHES SOMETHING IN YOUR HTML!!!
      $('.jeans2').each(function() {
          $(this).qtip({
              content: {
                  text: $(this).next('.tooltiptext4')
              },
              position: {
                at: 'bottom center',
                my: 'bottom center',
              target: $(window), // Track the mouse as the positioning target
              adjust: {
                  // Don't adjust continuously the mouse, just use initial position
                  mouse: false
                }
            },
            show: 'click',
            hide: 'click unfocus'
          });
      });
  });

  $(document).ready(function()
  {
      // MAKE SURE YOUR SELECTOR MATCHES SOMETHING IN YOUR HTML!!!
      $('.jacket').each(function() {
          $(this).qtip({
              content: {
                  text: $(this).next('.tooltiptext5')
              },
              position: {
                at: 'bottom center',
                my: 'bottom center',
              target: $(window), // Track the mouse as the positioning target
              adjust: {
                  // Don't adjust continuously the mouse, just use initial position
                  mouse: false
                }
            },
            show: 'click',
            hide: 'click unfocus'
          });
      });
  });

  $(document).ready(function()
  {
      // MAKE SURE YOUR SELECTOR MATCHES SOMETHING IN YOUR HTML!!!
      $('.tee').each(function() {
          $(this).qtip({
              content: {
                  text: $(this).next('.tooltiptext6')
              },
              position: {
                at: 'bottom center',
                my: 'bottom center',
              target: $(window), // Track the mouse as the positioning target
              adjust: {
                  // Don't adjust continuously the mouse, just use initial position
                  mouse: false
                }
            },
            show: 'click',
            hide: 'click unfocus'
          });
      });
  });

  $(document).ready(function()
  {
      // MAKE SURE YOUR SELECTOR MATCHES SOMETHING IN YOUR HTML!!!
      $('.overall').each(function() {
          $(this).qtip({
              content: {
                  text: $(this).next('.tooltiptext7')
              },
              position: {
                at: 'bottom center',
                my: 'bottom center',
              target: $(window), // Track the mouse as the positioning target
              adjust: {
                  // Don't adjust continuously the mouse, just use initial position
                  mouse: false
                }
            },
            show: 'click',
            hide: 'click unfocus'
          });
      });
  });


  $(document).ready(function() {
    $('map').imageMapResize();
});